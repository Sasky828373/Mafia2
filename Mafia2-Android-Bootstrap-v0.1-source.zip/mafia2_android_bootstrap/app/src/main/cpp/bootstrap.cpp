#include <jni.h>
#include <vulkan/vulkan.h>
#include <dlfcn.h>
#include <sstream>
#include <vector>
#include <cstring>

static bool has_vk_device(std::string& name) {
  VkApplicationInfo ai{VK_STRUCTURE_TYPE_APPLICATION_INFO}; ai.pApplicationName="Mafia2Bootstrap"; ai.apiVersion=VK_API_VERSION_1_1;
  VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO}; ci.pApplicationInfo=&ai;
  VkInstance inst=VK_NULL_HANDLE; if(vkCreateInstance(&ci,nullptr,&inst)!=VK_SUCCESS) return false;
  uint32_t n=0; vkEnumeratePhysicalDevices(inst,&n,nullptr); std::vector<VkPhysicalDevice> devs(n); if(n) vkEnumeratePhysicalDevices(inst,&n,devs.data());
  if(n){ VkPhysicalDeviceProperties p{}; vkGetPhysicalDeviceProperties(devs[0],&p); name=p.deviceName; }
  vkDestroyInstance(inst,nullptr); return n>0;
}

extern "C" JNIEXPORT jstring JNICALL Java_com_m2port_bootstrap_MainActivity_nativeProbe(JNIEnv* env,jclass){
  std::ostringstream o; o << "Mafia II Android ARM64 Bootstrap v0.1\\n\\n";
#if defined(__aarch64__)
  o << "CPU ABI: ARM64 OK\\n";
#else
  o << "CPU ABI: not ARM64\\n";
#endif
  std::string gpu; o << "Vulkan: " << (has_vk_device(gpu)?"OK":"FAILED") << "\\n"; if(!gpu.empty()) o << "GPU: " << gpu << "\\n";
  void* dxvk=dlopen("libdxvk_d3d9.so",RTLD_NOW|RTLD_LOCAL);
  o << "DXVK D3D9 module: " << (dxvk?"FOUND":"not bundled yet") << "\\n"; if(dxvk) dlclose(dxvk);
  void* game=dlopen("libmafia2_recomp.so",RTLD_NOW|RTLD_LOCAL);
  o << "Mafia II ARM64 recomp module: " << (game?"FOUND":"missing (next milestone)") << "\\n\\n";
  o << "Original Mafia2.exe is PE32/i386 and cannot be dlopen()'d on Android ARM64.\\n";
  o << "Next: x86 static recompilation / CPU bridge + Win32 ABI layer, then route D3D9 to DXVK.";
  if(game) dlclose(game);
  return env->NewStringUTF(o.str().c_str());
}
