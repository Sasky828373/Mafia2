# Mafia II Android ARM64 Bootstrap v0.1

First-stage Android host for a future Mafia II recompilation port.

## What it already does
- ARM64-only Android target
- creates a Vulkan 1.1 instance and enumerates the GPU
- probes for a future `libdxvk_d3d9.so`
- probes for a future `libmafia2_recomp.so`
- keeps original proprietary game files outside the project/APK

## Architecture
`libmafia2_recomp.so` -> Win32 compatibility ABI -> D3D9 shim/DXVK -> Vulkan -> Android GPU driver/Turnip

## Current blocker
The supplied `mafia2.exe` is PE32 Intel i386. Android ARM64 cannot load it as a native shared object. The next milestone is a static x86 recompilation/translation layer and implementation of the Win32 imports used by the translated code.

PhysX/APEX should initially remain behind a compatibility boundary rather than being blindly removed; gameplay depends heavily on it.

## Build
Requires Android SDK + NDK and JDK 17. Open the directory in Android Studio or run Gradle after configuring the Android SDK.
