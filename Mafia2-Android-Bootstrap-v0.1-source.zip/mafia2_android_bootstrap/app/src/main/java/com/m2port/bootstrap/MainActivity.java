package com.m2port.bootstrap;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public final class MainActivity extends Activity {
  static { System.loadLibrary("m2bootstrap"); }
  private static native String nativeProbe();
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    TextView v = new TextView(this);
    v.setText(nativeProbe()); v.setTextSize(16); v.setPadding(24,24,24,24);
    setContentView(v);
  }
}
